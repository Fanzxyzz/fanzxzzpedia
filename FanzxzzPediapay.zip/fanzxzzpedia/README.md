# FanzxzzPedia Payment Gateway

Website Payment Gateway berbasis **Node.js + Express + EJS** dengan integrasi:

- QRIS Auto Deposit via **RamaShop API** (`https://ramashop.my.id`)
- Telegram Bot (notifikasi deposit, withdraw approval, link apikey)
- Live Chat realtime (Socket.io)
- User balance, API Key, Deposit, Withdraw (DANA / GoPay / OVO)

## Fitur

### Landing
- Layanan Payment Gateway
- Keunggulan: 99% Fast & Secure, Admin Online 24 jam, Withdraw Fast, Pembayaran Fast
- Tombol **Mulakan, Lanjut** → Login
- Tombol **Docs Api**

### Dashboard
- Jumlah saldo & profile
- Live Chat bersama semua user & owner
- Sidebar: Deposit, Withdraw, Docs Api, Apikey, Profile

### Deposit
- Generate QRIS via RamaShop API
- Auto polling status
- Notifikasi ke channel Telegram saat berhasil

### Withdraw
- Pilih ewallet: DANA / GoPay / OVO
- Notifikasi ke Owner untuk **Setuju / Tidak Setuju**
- Auto balasan ke user setelah diproses

### Telegram Bot
- `/start` → welcome + tombol
- `/link APIKEY` → hubungkan akun
- `/wd NOMOR EWALLET` → ajukan withdraw
- Notifikasi deposit sukses ke channel
- Approve/Reject withdraw oleh owner

## Instalasi

```bash
# 1. Extract zip
cd FanzxzzPedia

# 2. Install dependency
npm install

# 3. Edit .env
cp .env.example .env
# Isi:
# - BOT_TOKEN (sudah diisi)
# - OWNER_ID (sudah diisi)
# - CHANNEL_USERNAME (sudah diisi)
# - RAMASHOP_API_KEY  ← WAJIB dari https://ramashop.my.id
# - WEBSITE_URL

# 4. Jalankan
npm start
```

Buka `http://localhost:3000`

## Penting

1. Daftar/Login di **https://ramashop.my.id** lalu ambil API Key, masukkan ke `.env` sebagai `RAMASHOP_API_KEY`.
2. Pastikan bot Telegram sudah di-start dan ditambahkan sebagai admin di channel `@fanzxzzjirr`.
3. Ganti `WEBSITE_URL` sesuai domain production kamu.

## Struktur Folder

```
FanzxzzPedia/
├── server.js
├── db.js
├── package.json
├── .env
├── routes/
│   ├── auth.js
│   ├── dashboard.js
│   └── api.js
├── utils/
│   ├── ramashop.js
│   └── telegram.js
├── views/
│   ├── landing.ejs
│   ├── login.ejs
│   ├── register.ejs
│   ├── dashboard.ejs
│   ├── deposit.ejs
│   ├── withdraw.ejs
│   ├── apikey.ejs
│   ├── docs.ejs
│   ├── docs-public.ejs
│   ├── profile.ejs
│   └── partials/sidebar.ejs
└── public/css/style.css
```

## API Endpoint (untuk user)

| Method | Endpoint | Keterangan |
|--------|----------|------------|
| GET | /api/balance | Cek saldo |
| POST | /api/deposit/create | Buat QRIS deposit |
| GET | /api/deposit/status/:id | Cek status deposit |

Header wajib: `X-API-Key: YOUR_API_KEY`
