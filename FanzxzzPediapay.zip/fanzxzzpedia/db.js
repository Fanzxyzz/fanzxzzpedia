const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const db = new Database(path.join(__dirname, 'fanzxzzpedia.db'));

db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    balance REAL DEFAULT 0,
    apikey TEXT UNIQUE,
    telegram_id TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS deposits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    deposit_id TEXT UNIQUE,
    amount REAL NOT NULL,
    total_amount REAL,
    status TEXT DEFAULT 'pending',
    qr_image TEXT,
    qr_string TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    paid_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS withdraws (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    ewallet TEXT NOT NULL,
    number TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    processed_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    username TEXT,
    message TEXT NOT NULL,
    is_owner INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

function createUser(username, password) {
  const hash = bcrypt.hashSync(password, 10);
  const apikey = 'FZ' + uuidv4().replace(/-/g, '').substring(0, 28).toUpperCase();
  const stmt = db.prepare('INSERT INTO users (username, password, apikey) VALUES (?, ?, ?)');
  const info = stmt.run(username, hash, apikey);
  return { id: info.lastInsertRowid, username, apikey, balance: 0 };
}

function findUserByUsername(username) {
  return db.prepare('SELECT * FROM users WHERE username = ?').get(username);
}

function findUserById(id) {
  return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
}

function findUserByApikey(apikey) {
  return db.prepare('SELECT * FROM users WHERE apikey = ?').get(apikey);
}

function findUserByTelegramId(telegramId) {
  return db.prepare('SELECT * FROM users WHERE telegram_id = ?').get(String(telegramId));
}

function updateBalance(userId, amount) {
  db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(amount, userId);
  return findUserById(userId);
}

function setBalance(userId, balance) {
  db.prepare('UPDATE users SET balance = ? WHERE id = ?').run(balance, userId);
}

function linkTelegram(userId, telegramId) {
  db.prepare('UPDATE users SET telegram_id = ? WHERE id = ?').run(String(telegramId), userId);
}

function createDeposit(userId, depositId, amount, totalAmount, qrImage, qrString) {
  const stmt = db.prepare(`
    INSERT INTO deposits (user_id, deposit_id, amount, total_amount, qr_image, qr_string, status)
    VALUES (?, ?, ?, ?, ?, ?, 'pending')
  `);
  return stmt.run(userId, depositId, amount, totalAmount, qrImage, qrString);
}

function updateDepositStatus(depositId, status) {
  const paidAt = status === 'success' ? new Date().toISOString() : null;
  db.prepare('UPDATE deposits SET status = ?, paid_at = ? WHERE deposit_id = ?').run(status, paidAt, depositId);
}

function getDeposit(depositId) {
  return db.prepare('SELECT * FROM deposits WHERE deposit_id = ?').get(depositId);
}

function getPendingDeposits() {
  return db.prepare("SELECT * FROM deposits WHERE status = 'pending'").all();
}

function createWithdraw(userId, amount, ewallet, number) {
  const stmt = db.prepare(`
    INSERT INTO withdraws (user_id, amount, ewallet, number, status)
    VALUES (?, ?, ?, ?, 'pending')
  `);
  const info = stmt.run(userId, amount, ewallet, number);
  return info.lastInsertRowid;
}

function getWithdraw(id) {
  return db.prepare('SELECT w.*, u.username, u.telegram_id FROM withdraws w JOIN users u ON w.user_id = u.id WHERE w.id = ?').get(id);
}

function updateWithdrawStatus(id, status) {
  db.prepare('UPDATE withdraws SET status = ?, processed_at = CURRENT_TIMESTAMP WHERE id = ?').run(status, id);
}

function addChatMessage(userId, username, message, isOwner = 0) {
  db.prepare('INSERT INTO chat_messages (user_id, username, message, is_owner) VALUES (?, ?, ?, ?)').run(userId, username, message, isOwner);
}

function getRecentChats(limit = 50) {
  return db.prepare('SELECT * FROM chat_messages ORDER BY id DESC LIMIT ?').all(limit).reverse();
}

function regenerateApikey(userId) {
  const apikey = 'FZ' + uuidv4().replace(/-/g, '').substring(0, 28).toUpperCase();
  db.prepare('UPDATE users SET apikey = ? WHERE id = ?').run(apikey, userId);
  return apikey;
}

module.exports = {
  db,
  createUser,
  findUserByUsername,
  findUserById,
  findUserByApikey,
  findUserByTelegramId,
  updateBalance,
  setBalance,
  linkTelegram,
  createDeposit,
  updateDepositStatus,
  getDeposit,
  getPendingDeposits,
  createWithdraw,
  getWithdraw,
  updateWithdrawStatus,
  addChatMessage,
  getRecentChats,
  regenerateApikey
};
