const express = require('express');
const router = express.Router();
const db = require('../db');
const ramashop = require('../utils/ramashop');
const telegram = require('../utils/telegram');

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.redirect('/login');
  next();
}

router.get('/', requireAuth, (req, res) => {
  const user = db.findUserById(req.session.userId);
  res.render('dashboard', {
    user,
    page: 'home',
    title: 'Dashboard'
  });
});

router.get('/deposit', requireAuth, (req, res) => {
  const user = db.findUserById(req.session.userId);
  res.render('deposit', {
    user,
    page: 'deposit',
    title: 'Deposit',
    result: null,
    error: null
  });
});

router.post('/deposit', requireAuth, async (req, res) => {
  const user = db.findUserById(req.session.userId);
  const amount = parseInt(req.body.amount);
  if (!amount || amount < 100) {
    return res.render('deposit', {
      user,
      page: 'deposit',
      title: 'Deposit',
      result: null,
      error: 'Minimal deposit Rp 100'
    });
  }

  const result = await ramashop.createDeposit(amount);
  if (!result.success) {
    return res.render('deposit', {
      user,
      page: 'deposit',
      title: 'Deposit',
      result: null,
      error: result.message || 'Gagal membuat deposit. Pastikan RAMASHOP_API_KEY sudah diisi.'
    });
  }

  const d = result.data;
  db.createDeposit(user.id, d.depositId, d.amount, d.totalAmount, d.qrImage, d.qrString);

  res.render('deposit', {
    user,
    page: 'deposit',
    title: 'Deposit',
    result: d,
    error: null
  });
});

router.get('/deposit/status/:depositId', requireAuth, async (req, res) => {
  const deposit = db.getDeposit(req.params.depositId);
  if (!deposit || deposit.user_id !== req.session.userId) {
    return res.json({ success: false, message: 'Not found' });
  }
  if (deposit.status === 'success') {
    return res.json({ success: true, status: 'success' });
  }

  const check = await ramashop.checkDepositStatus(req.params.depositId);
  if (check.data && check.data.status === 'success') {
    db.updateDepositStatus(req.params.depositId, 'success');
    const updatedUser = db.updateBalance(deposit.user_id, deposit.amount);
    // Notif channel
    await telegram.notifyDepositSuccess({
      nominal: 'Rp ' + Number(deposit.amount).toLocaleString('id-ID'),
      invoiceId: deposit.deposit_id,
      username: updatedUser.username,
      saldoSekarang: 'Rp ' + Number(updatedUser.balance).toLocaleString('id-ID')
    });
    return res.json({ success: true, status: 'success', balance: updatedUser.balance });
  }
  res.json({ success: true, status: check.data?.status || 'pending' });
});

router.get('/withdraw', requireAuth, (req, res) => {
  const user = db.findUserById(req.session.userId);
  res.render('withdraw', {
    user,
    page: 'withdraw',
    title: 'Withdraw',
    success: null,
    error: null
  });
});

router.post('/withdraw', requireAuth, (req, res) => {
  const user = db.findUserById(req.session.userId);
  const amount = parseInt(req.body.amount);
  const ewallet = (req.body.ewallet || '').toLowerCase();
  const number = (req.body.number || '').replace(/\D/g, '');

  if (!amount || amount <= 0) {
    return res.render('withdraw', { user, page: 'withdraw', title: 'Withdraw', success: null, error: 'Nominal tidak valid' });
  }
  if (amount > user.balance) {
    return res.render('withdraw', { user, page: 'withdraw', title: 'Withdraw', success: null, error: 'Saldo tidak cukup' });
  }
  if (!['dana', 'gopay', 'ovo'].includes(ewallet)) {
    return res.render('withdraw', { user, page: 'withdraw', title: 'Withdraw', success: null, error: 'Ewallet harus dana / gopay / ovo' });
  }
  if (number.length < 10) {
    return res.render('withdraw', { user, page: 'withdraw', title: 'Withdraw', success: null, error: 'Nomor ewallet tidak valid' });
  }

  // Kurangi saldo
  db.updateBalance(user.id, -amount);
  const wdId = db.createWithdraw(user.id, amount, ewallet, number);

  // Notif owner via Telegram
  const bot = telegram.getBot();
  if (bot) {
    const notif = `<blockquote>Notif User Whitdraw!!</blockquote>
─────────────────
methode payment ewallet : ${ewallet.toUpperCase()}
nomor ewallet : ${number}
Username : ${user.username}
Nominal : Rp ${amount.toLocaleString('id-ID')}
Sila Tekan Tombol Dibawah`;

    bot.sendMessage(process.env.OWNER_ID, notif, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [[
          { text: 'Setuju', callback_data: `wd_approve_${wdId}` },
          { text: 'Tidak Setuju', callback_data: `wd_reject_${wdId}` }
        ]]
      }
    });
  }

  const updated = db.findUserById(user.id);
  res.render('withdraw', {
    user: updated,
    page: 'withdraw',
    title: 'Withdraw',
    success: 'Permintaan withdraw berhasil dikirim. Menunggu persetujuan owner.',
    error: null
  });
});

router.get('/apikey', requireAuth, (req, res) => {
  const user = db.findUserById(req.session.userId);
  res.render('apikey', {
    user,
    page: 'apikey',
    title: 'API Key'
  });
});

router.post('/apikey/regenerate', requireAuth, (req, res) => {
  const newKey = db.regenerateApikey(req.session.userId);
  res.redirect('/apikey');
});

router.get('/docs', requireAuth, (req, res) => {
  const user = db.findUserById(req.session.userId);
  res.render('docs', {
    user,
    page: 'docs',
    title: 'Dokumentasi API'
  });
});

router.get('/profile', requireAuth, (req, res) => {
  const user = db.findUserById(req.session.userId);
  res.render('profile', {
    user,
    page: 'profile',
    title: 'Profile'
  });
});

module.exports = router;
