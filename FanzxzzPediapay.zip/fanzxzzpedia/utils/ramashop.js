const BASE_URL = process.env.RAMASHOP_BASE_URL || 'https://ramashop.my.id/api/public';
const API_KEY = process.env.RAMASHOP_API_KEY;

async function getBalance() {
  if (!API_KEY || API_KEY.includes('MASUKKAN')) {
    return { success: false, message: 'RAMASHOP_API_KEY belum diisi di .env' };
  }
  try {
    const res = await fetch(`${BASE_URL}/balance`, {
      headers: { 'X-API-Key': API_KEY }
    });
    return await res.json();
  } catch (err) {
    return { success: false, message: err.message };
  }
}

async function createDeposit(amount) {
  if (!API_KEY || API_KEY.includes('MASUKKAN')) {
    return { success: false, message: 'RAMASHOP_API_KEY belum diisi di .env' };
  }
  try {
    const res = await fetch(`${BASE_URL}/deposit/create`, {
      method: 'POST',
      headers: {
        'X-API-Key': API_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ amount: Number(amount), method: 'qris' })
    });
    return await res.json();
  } catch (err) {
    return { success: false, message: err.message };
  }
}

async function checkDepositStatus(depositId) {
  if (!API_KEY || API_KEY.includes('MASUKKAN')) {
    return { success: false, message: 'RAMASHOP_API_KEY belum diisi di .env' };
  }
  try {
    const res = await fetch(`${BASE_URL}/deposit/status/${depositId}`, {
      headers: { 'X-API-Key': API_KEY }
    });
    return await res.json();
  } catch (err) {
    return { success: false, message: err.message };
  }
}

module.exports = { getBalance, createDeposit, checkDepositStatus };
